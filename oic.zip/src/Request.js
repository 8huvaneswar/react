import React, { Component } from 'react';
import 'antd/dist/antd.css';
import './Breadcrumbs.css';
import { Icon } from 'antd';

class Request extends Component {

    render() {
        return (
            <div>
            <div class="row">
            <div class="col-md-3">
                <h4 className="head-4"><Icon type="wallet" /> 34732</h4> 
                <h5 className="para">Dealer Price</h5> 
            </div>

            <div class="col-md-3">
                <h4 className="head-4">10</h4> 
                <h5 className="para">Available Units</h5> 
            </div>

            <div class="col-md-6 text-center">
                <button class="btn-request">Request To Buy</button>
            </div>
            </div>
            </div>
   );
}
}

export default Request;          