import React, { Component } from 'react';
import 'antd/dist/antd.css';
import './Breadcrumbs.css';
import Order from './images/IncommingOrders.png';
import Cart from './images/cart.png';
import Avator from './images/avatar.jpg';
import { Row, Col } from 'antd';

class Action extends Component {

    render() {
        return (
            <div className="top-action bg-white">
            <Row>
                <Col span={6}><h1 className="head-1">Marketplace</h1> </Col>
                <Col className="text-right" span={18}>
                <Col span={9}> </Col>
                    <Col className="mt-10" span={6}><span class="cart-count">0</span><img src={Order} className="action-logo" alt="" /> Incoming Orders  </Col>
                    <Col className="mt-10" span={6}><span class="cart-count">0</span><img src={Cart} className="action-logo" alt="" /> My Order </Col>
                    <Col className="mt-10" span={3}><img src={Avator} className="action-logo" alt="" width="30%" /></Col>
                </Col>
            </Row>
        </div>
   );
}
}

export default Action;          