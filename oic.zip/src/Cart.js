import React, { Component } from 'react';
import 'antd/dist/antd.css';
import './Cart.css';
import Breadcrumbs from "./Breadcrumbs";
import Action from "./Action";
import Specks from "./Specks";
import Request from "./Request";
import { Row, Col } from 'antd';
import { CirclePicker } from 'react-color';
import { Icon } from 'antd';

class Cart extends Component {
    state = {
        background: '#fff',
    };

    handleChangeComplete = (color) => {
        this.setState({ background: color.hex });
    };

    render() {
        return (
            <div>
                <div>
                    <Row>
                        <div>
                            <Col span={24}><Action /></Col>
                        </div>
                        <div>
                            <Col span={24}> <Breadcrumbs /></Col>
                        </div>
                    </Row>
                </div>

                <div>
                    <Row>
                        <div>
                            <Col className="card-1" span={11}> <Specks /></Col>
                        </div>
                        <div>
                            <Col span={12}>
                            <div>
                                <h4 className="head-4">RAYBAN EYEGLASS SMALL PINK</h4>
                                <p className="para">By <a href="">Style Opticals</a></p>
                            </div>
                            <div className="card-1">
                            <Request />
                            </div>
                            <Row className="card-1">
                            <div>
                            <Col span={12}>
                            <div>
                            <h5 className="head-5">SIZE</h5>
                            <div className="box-size">
                            <div className="width-75">
                            <h5>Small</h5>
                            <p>48cm or less</p>
                            </div>
                            <div className="width-25">
                            <Icon type="check" />
                            </div>
                            </div>
                            <div className="box-size-1">
                            <div className="width-75">
                            <h5>Medium</h5>
                            <p>49 - 56</p>
                            </div>
                            <div className="width-25">
                            <Icon type="check" />
                            </div>
                            </div>
                            </div>
                            </Col>
                            <Col span={12}>
                            <h5 className="head-5">COLOR</h5>
                            <CirclePicker className="mt-10" color={this.state.background} onChangeComplete={this.handleChangeComplete} />
                            </Col>
                            </div>
                            </Row>
                            <div>
                    <Row>
                    <Col span={24}>
                    <div class="card-1 selection">
                        <div class="row">
                        <div class="col-md-3">
                            <h5>Frame Type</h5>
                            <h4>FULLRIM</h4>
                        </div>
                        <div class="col-md-3">
                            <h5>Shape</h5>
                            <h4>WAYFARER</h4>
                        </div>
                        <div class="col-md-3">
                            <h5>Color</h5>
                            <h4></h4>
                        </div>
                        <div class="col-md-3">
                            <h5>Gender</h5>
                            <h4>UNISEX</h4>
                        </div>
                        <div class="col-md-3 mt-20">
                            <h5>Rim Color</h5>
                            <h4>TORTOISE</h4>
                        </div>
                        <div class="col-md-3 mt-20">
                            <h5>Frontal Color</h5>
                            <h4></h4>
                        </div>
                        <div class="col-md-3 mt-20">
                            <h5>Temple Color</h5>
                            <h4>TORTOISE</h4>
                        </div>
                        <div class="col-md-3 mt-20">
                            <h5>Glass Color</h5>
                            <h4>TRANSPARENT</h4>
                        </div>
                        </div>
                    </div>
                    </Col>
                    </Row>
                    </div>
                            </Col>
                        </div>
                    </Row>
                    
                </div>
            </div>
        );
    }
}

export default Cart;          