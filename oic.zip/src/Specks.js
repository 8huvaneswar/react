import React, { Component } from 'react';
import 'antd/dist/antd.css';
import './Cart.css';
import specks from './images/specks.png';
import { Row, Col } from 'antd';
import 'bootstrap/dist/css/bootstrap.css';

class Specks extends Component {

    render() {
        return (
            <div>
                <Row>
                    <div>
                        <Col span={24}>
                            <div className="tab-content">
                                <div className="tab-pane container active" id="home"><img src={specks} alt="" className="img-fluid" /></div>
                                <div className="tab-pane container fade" id="menu1"><img src={specks} className="img-fluid" alt="" /></div>
                                <div className="tab-pane container fade" id="menu2"><img src={specks} className="img-fluid" alt="" /></div>
                            </div>
                        </Col>
                    </div>
                    <Col span={24}>
                        <ul className="nav nav-pills ml-20">
                            <li className="nav-item">
                                <a className="nav-link active" data-toggle="pill" href="#home"><img src={specks} width="100%" alt="" /></a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" data-toggle="pill" href="#menu1"><img src={specks} width="100%" alt="" /></a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" data-toggle="pill" href="#menu2"><img src={specks} width="100%" alt="" /></a>
                            </li>
                        </ul>
                    </Col>
                </Row>
            </div>

        );
    }
}

export default Specks;          