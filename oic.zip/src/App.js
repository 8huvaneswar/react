import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Header from "./Header";
import Cart from "./Cart";
import { Row, Col } from 'antd';

class App extends Component {
  render() {
    return (
      <div className="App">
      {/* <img src={require('./logo.svg')} className="App-logo" alt="logo" /> */}
      <Row>
        <Col span={5}><Header /> </Col>
        <Col span={19}><Cart /></Col>
      </Row>
      
      </div>
    );
  }
}

export default App;
