import React, { Component } from 'react';
import 'antd/dist/antd.css';
import './Breadcrumbs.css';
import { Breadcrumb } from 'antd';

class Breadcrumbs extends Component {

    render() {
        return (
  <Breadcrumb separator=">">
    <Breadcrumb.Item>Market Place</Breadcrumb.Item>
    <Breadcrumb.Item href="">Rayban Eyeglass</Breadcrumb.Item>
  </Breadcrumb>
   );
}
}

export default Breadcrumbs;          